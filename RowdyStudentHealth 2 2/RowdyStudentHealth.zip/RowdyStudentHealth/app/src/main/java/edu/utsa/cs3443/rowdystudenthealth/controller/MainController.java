package edu.utsa.cs3443.rowdystudenthealth.controller;

import android.content.Intent;

public class MainController {

    // variables
    private static String key = "username";

    // constructor

    /**
     * Method: getUsername
     * Description: Gets the username of the user signed in from the Intent object.
     * @param intent - an Intent object that holds the username.
     * @return - a String with the username of the signed in user.
     */
    public static String getUsername( Intent intent ) {
        return intent.getStringExtra(key);
    }
}